-- Copyright (C) 2018  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 18.1.0 Build 625 09/12/2018 SJ Lite Edition"

-- DATE "04/11/2020 11:06:37"

-- 
-- Device: Altera EPM240T100C5 Package TQFP100
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY IEEE;
LIBRARY MAXII;
USE IEEE.STD_LOGIC_1164.ALL;
USE MAXII.MAXII_COMPONENTS.ALL;

ENTITY 	divider_sig_var IS
    PORT (
	clk_in : IN std_logic;
	clk_out_var : OUT std_logic;
	clk_out_sig : OUT std_logic
	);
END divider_sig_var;

ARCHITECTURE structure OF divider_sig_var IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk_in : std_logic;
SIGNAL ww_clk_out_var : std_logic;
SIGNAL ww_clk_out_sig : std_logic;
SIGNAL \clk_in~combout\ : std_logic;
SIGNAL \P_div_var:count_var[1]~regout\ : std_logic;
SIGNAL \P_div_var:count_var[2]~regout\ : std_logic;
SIGNAL \P_div_var:count_var[0]~regout\ : std_logic;
SIGNAL \temp_var~regout\ : std_logic;
SIGNAL \temp_sig~regout\ : std_logic;
SIGNAL count_sig : std_logic_vector(2 DOWNTO 0);

BEGIN

ww_clk_in <= clk_in;
clk_out_var <= ww_clk_out_var;
clk_out_sig <= ww_clk_out_sig;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\clk_in~I\ : maxii_io
-- pragma translate_off
GENERIC MAP (
	operation_mode => "input")
-- pragma translate_on
PORT MAP (
	oe => GND,
	padio => ww_clk_in,
	combout => \clk_in~combout\);

\P_div_var:count_var[1]\ : maxii_lcell
-- Equation(s):
-- \P_div_var:count_var[1]~regout\ = DFFEAS(((\P_div_var:count_var[0]~regout\ $ (\P_div_var:count_var[1]~regout\))), \clk_in~combout\, VCC, , , , , , )

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0ff0",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	clk => \clk_in~combout\,
	datac => \P_div_var:count_var[0]~regout\,
	datad => \P_div_var:count_var[1]~regout\,
	aclr => GND,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \P_div_var:count_var[1]~regout\);

\P_div_var:count_var[2]\ : maxii_lcell
-- Equation(s):
-- \P_div_var:count_var[2]~regout\ = DFFEAS(((\P_div_var:count_var[0]~regout\ & (\P_div_var:count_var[1]~regout\ $ (\P_div_var:count_var[2]~regout\))) # (!\P_div_var:count_var[0]~regout\ & (\P_div_var:count_var[1]~regout\ & 
-- \P_div_var:count_var[2]~regout\))), \clk_in~combout\, VCC, , , , , , )

-- pragma translate_off
GENERIC MAP (
	lut_mask => "3cc0",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	clk => \clk_in~combout\,
	datab => \P_div_var:count_var[0]~regout\,
	datac => \P_div_var:count_var[1]~regout\,
	datad => \P_div_var:count_var[2]~regout\,
	aclr => GND,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \P_div_var:count_var[2]~regout\);

\P_div_var:count_var[0]\ : maxii_lcell
-- Equation(s):
-- \P_div_var:count_var[0]~regout\ = DFFEAS((!\P_div_var:count_var[0]~regout\ & (((\P_div_var:count_var[1]~regout\)) # (!\P_div_var:count_var[2]~regout\))), \clk_in~combout\, VCC, , , , , , )

-- pragma translate_off
GENERIC MAP (
	lut_mask => "5511",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	clk => \clk_in~combout\,
	dataa => \P_div_var:count_var[0]~regout\,
	datab => \P_div_var:count_var[2]~regout\,
	datad => \P_div_var:count_var[1]~regout\,
	aclr => GND,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \P_div_var:count_var[0]~regout\);

temp_var : maxii_lcell
-- Equation(s):
-- \temp_var~regout\ = DFFEAS(\temp_var~regout\ $ (((!\P_div_var:count_var[0]~regout\ & (!\P_div_var:count_var[1]~regout\ & \P_div_var:count_var[2]~regout\)))), \clk_in~combout\, VCC, , , , , , )

-- pragma translate_off
GENERIC MAP (
	lut_mask => "a9aa",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	clk => \clk_in~combout\,
	dataa => \temp_var~regout\,
	datab => \P_div_var:count_var[0]~regout\,
	datac => \P_div_var:count_var[1]~regout\,
	datad => \P_div_var:count_var[2]~regout\,
	aclr => GND,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \temp_var~regout\);

\count_sig[0]\ : maxii_lcell
-- Equation(s):
-- count_sig(0) = DFFEAS((!count_sig(0)), \clk_in~combout\, VCC, , , , , , )

-- pragma translate_off
GENERIC MAP (
	lut_mask => "5555",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	clk => \clk_in~combout\,
	dataa => count_sig(0),
	aclr => GND,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => count_sig(0));

\count_sig[2]\ : maxii_lcell
-- Equation(s):
-- count_sig(2) = DFFEAS(((count_sig(2) & ((!count_sig(0)))) # (!count_sig(2) & (count_sig(1) & count_sig(0)))), \clk_in~combout\, VCC, , , , , , )

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0af0",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	clk => \clk_in~combout\,
	dataa => count_sig(1),
	datac => count_sig(2),
	datad => count_sig(0),
	aclr => GND,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => count_sig(2));

\count_sig[1]\ : maxii_lcell
-- Equation(s):
-- count_sig(1) = DFFEAS(((count_sig(1) & ((!count_sig(0)))) # (!count_sig(1) & (!count_sig(2) & count_sig(0)))), \clk_in~combout\, VCC, , , , , , )

-- pragma translate_off
GENERIC MAP (
	lut_mask => "03cc",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	clk => \clk_in~combout\,
	datab => count_sig(1),
	datac => count_sig(2),
	datad => count_sig(0),
	aclr => GND,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => count_sig(1));

temp_sig : maxii_lcell
-- Equation(s):
-- \temp_sig~regout\ = DFFEAS(\temp_sig~regout\ $ (((!count_sig(1) & (count_sig(0) & count_sig(2))))), \clk_in~combout\, VCC, , , , , , )

-- pragma translate_off
GENERIC MAP (
	lut_mask => "9aaa",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	clk => \clk_in~combout\,
	dataa => \temp_sig~regout\,
	datab => count_sig(1),
	datac => count_sig(0),
	datad => count_sig(2),
	aclr => GND,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \temp_sig~regout\);

\clk_out_var~I\ : maxii_io
-- pragma translate_off
GENERIC MAP (
	operation_mode => "output")
-- pragma translate_on
PORT MAP (
	datain => \temp_var~regout\,
	oe => VCC,
	padio => ww_clk_out_var);

\clk_out_sig~I\ : maxii_io
-- pragma translate_off
GENERIC MAP (
	operation_mode => "output")
-- pragma translate_on
PORT MAP (
	datain => \temp_sig~regout\,
	oe => VCC,
	padio => ww_clk_out_sig);
END structure;


