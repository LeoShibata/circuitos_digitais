-- Copyright (C) 2018  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details.

-- *****************************************************************************
-- This file contains a Vhdl test bench with test vectors .The test vectors     
-- are exported from a vector file in the Quartus Waveform Editor and apply to  
-- the top level entity of the current Quartus project .The user can use this   
-- testbench to simulate his design using a third-party simulation tool .       
-- *****************************************************************************
-- Generated on "04/11/2020 11:06:32"
                                                             
-- Vhdl Test Bench(with test vectors) for design  :          divider_sig_var
-- 
-- Simulation tool : 3rd Party
-- 

LIBRARY ieee;                                               
USE ieee.std_logic_1164.all;                                

ENTITY divider_sig_var_vhd_vec_tst IS
END divider_sig_var_vhd_vec_tst;
ARCHITECTURE divider_sig_var_arch OF divider_sig_var_vhd_vec_tst IS
-- constants                                                 
-- signals                                                   
SIGNAL clk_in : STD_LOGIC;
SIGNAL clk_out_sig : STD_LOGIC;
SIGNAL clk_out_var : STD_LOGIC;
COMPONENT divider_sig_var
	PORT (
	clk_in : IN STD_LOGIC;
	clk_out_sig : OUT STD_LOGIC;
	clk_out_var : OUT STD_LOGIC
	);
END COMPONENT;
BEGIN
	i1 : divider_sig_var
	PORT MAP (
-- list connections between master ports and signals
	clk_in => clk_in,
	clk_out_sig => clk_out_sig,
	clk_out_var => clk_out_var
	);

-- clk_in
t_prcs_clk_in: PROCESS
BEGIN
LOOP
	clk_in <= '0';
	WAIT FOR 25000 ps;
	clk_in <= '1';
	WAIT FOR 25000 ps;
	IF (NOW >= 1000000 ps) THEN WAIT; END IF;
END LOOP;
END PROCESS t_prcs_clk_in;
END divider_sig_var_arch;
