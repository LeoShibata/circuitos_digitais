----------------------------------------------------------------------------
-- UTFPR - Universidade Tecnol�gica Federal do Paraná - Curitiba - PR
-- Projeto : Divisor de frequência
-- Arquivo : divider_sig_var.vhd
-- Autor   : prof. Gortan
-- Data    : Abril 2020
--
----------------------------------------------------------------------------
-- Descrição :
-- divisor de frequência genérico - mostra a diferença entre uso de 
-- signal e variable
-- variable é atualizadas durante a execução do processo
-- signal é atualizado somente após o término do processo (no próximo clk)
-- variable usa sinal de atribuição :=, signal usa <=
-- variable é visível só localmente dentro do processo onde é declarada
-- signal é visível globalmente - dentro e fora do processo
----------------------------------------------------------------------------

library ieee;
  use ieee.std_logic_1164.all;

entity divider_sig_var is
  generic(divisor: integer := 5);
  port(
    clk_in		: in  std_logic;	-- clock in.
    clk_out_var	: out std_logic;	-- clock in dividido 2 x divisor - usa var
	clk_out_sig : out std_logic		-- clock in dividido 2 x divisor - usa sig
    );
end divider_sig_var;
----------------------------------------------------------------------------
architecture divisor of divider_sig_var is
signal temp_var: std_logic :='0';				-- usada no proces com variable
signal temp_sig: std_logic :='0';				-- usada no processo com signal
signal count_sig: integer range 0 to divisor; 	-- usada no processo com signal
begin
--================== Processo usando variable: ================================
	P_div_var:process (clk_in)                                              
	variable count_var: integer range 0 to divisor;
	begin                                                                
		if clk_in'event and clk_in = '1' then
			count_var := count_var + 1;
			if (count_var = divisor) then
				temp_var <= not temp_var;
				count_var := 0;
			end if;
		 end if; 
	end process P_div_var;
	clk_out_var <= temp_var;
--================== Processo usando signal: ==================================
	P_div_sig:process (clk_in)
	begin
		if clk_in'event and clk_in = '1' then
			count_sig <= count_sig + 1;
			if (count_sig = divisor) then
				temp_sig <= not temp_sig;
				count_sig <= 0;
			end if;
		 end if; 
	end process P_div_sig;
	clk_out_sig <= temp_sig;

end divisor;
