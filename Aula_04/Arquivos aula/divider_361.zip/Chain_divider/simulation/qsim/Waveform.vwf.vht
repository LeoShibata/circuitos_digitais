-- Copyright (C) 2018  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details.

-- *****************************************************************************
-- This file contains a Vhdl test bench with test vectors .The test vectors     
-- are exported from a vector file in the Quartus Waveform Editor and apply to  
-- the top level entity of the current Quartus project .The user can use this   
-- testbench to simulate his design using a third-party simulation tool .       
-- *****************************************************************************
-- Generated on "04/10/2020 15:59:21"
                                                             
-- Vhdl Test Bench(with test vectors) for design  :          divider
-- 
-- Simulation tool : 3rd Party
-- 

LIBRARY ieee;                                               
USE ieee.std_logic_1164.all;                                

ENTITY divider_vhd_vec_tst IS
END divider_vhd_vec_tst;
ARCHITECTURE divider_arch OF divider_vhd_vec_tst IS
-- constants                                                 
-- signals                                                   
SIGNAL clk_in : STD_LOGIC;
SIGNAL clk_out_1 : STD_LOGIC;
SIGNAL clk_out_2 : STD_LOGIC;
COMPONENT divider
	PORT (
	clk_in : IN STD_LOGIC;
	clk_out_1 : OUT STD_LOGIC;
	clk_out_2 : OUT STD_LOGIC
	);
END COMPONENT;
BEGIN
	i1 : divider
	PORT MAP (
-- list connections between master ports and signals
	clk_in => clk_in,
	clk_out_1 => clk_out_1,
	clk_out_2 => clk_out_2
	);

-- clk_in
t_prcs_clk_in: PROCESS
BEGIN
LOOP
	clk_in <= '0';
	WAIT FOR 10000 ps;
	clk_in <= '1';
	WAIT FOR 10000 ps;
	IF (NOW >= 1000000 ps) THEN WAIT; END IF;
END LOOP;
END PROCESS t_prcs_clk_in;
END divider_arch;
