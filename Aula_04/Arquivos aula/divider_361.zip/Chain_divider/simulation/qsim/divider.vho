-- Copyright (C) 2018  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 18.1.0 Build 625 09/12/2018 SJ Lite Edition"

-- DATE "04/10/2020 15:59:26"

-- 
-- Device: Altera EPM240T100C5 Package TQFP100
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY IEEE;
LIBRARY MAXII;
USE IEEE.STD_LOGIC_1164.ALL;
USE MAXII.MAXII_COMPONENTS.ALL;

ENTITY 	divider IS
    PORT (
	clk_in : IN std_logic;
	clk_out_1 : OUT std_logic;
	clk_out_2 : OUT std_logic
	);
END divider;

-- Design Ports Information


ARCHITECTURE structure OF divider IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk_in : std_logic;
SIGNAL ww_clk_out_1 : std_logic;
SIGNAL ww_clk_out_2 : std_logic;
SIGNAL \clk_in~combout\ : std_logic;
SIGNAL \P_div:count_1[1]~regout\ : std_logic;
SIGNAL \P_div:count_1[2]~regout\ : std_logic;
SIGNAL \P_div:count_1[0]~regout\ : std_logic;
SIGNAL \Equal0~0_combout\ : std_logic;
SIGNAL \temp_1~regout\ : std_logic;
SIGNAL \P_div:count_2[0]~regout\ : std_logic;
SIGNAL \P_div:count_2[1]~regout\ : std_logic;
SIGNAL \temp_2~regout\ : std_logic;

BEGIN

ww_clk_in <= clk_in;
clk_out_1 <= ww_clk_out_1;
clk_out_2 <= ww_clk_out_2;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

-- Location: PIN_14,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
\clk_in~I\ : maxii_io
-- pragma translate_off
GENERIC MAP (
	operation_mode => "input")
-- pragma translate_on
PORT MAP (
	oe => GND,
	padio => ww_clk_in,
	combout => \clk_in~combout\);

-- Location: LC_X7_Y1_N1
\P_div:count_1[1]\ : maxii_lcell
-- Equation(s):
-- \P_div:count_1[1]~regout\ = DFFEAS(((\P_div:count_1[1]~regout\ $ (\P_div:count_1[0]~regout\))), GLOBAL(\clk_in~combout\), VCC, , , , , , )

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0ff0",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	clk => \clk_in~combout\,
	datac => \P_div:count_1[1]~regout\,
	datad => \P_div:count_1[0]~regout\,
	aclr => GND,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \P_div:count_1[1]~regout\);

-- Location: LC_X7_Y1_N6
\P_div:count_1[2]\ : maxii_lcell
-- Equation(s):
-- \P_div:count_1[2]~regout\ = DFFEAS(((\P_div:count_1[2]~regout\ & (\P_div:count_1[1]~regout\ $ (\P_div:count_1[0]~regout\))) # (!\P_div:count_1[2]~regout\ & (\P_div:count_1[1]~regout\ & \P_div:count_1[0]~regout\))), GLOBAL(\clk_in~combout\), VCC, , , , , , 
-- )

-- pragma translate_off
GENERIC MAP (
	lut_mask => "3cc0",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	clk => \clk_in~combout\,
	datab => \P_div:count_1[2]~regout\,
	datac => \P_div:count_1[1]~regout\,
	datad => \P_div:count_1[0]~regout\,
	aclr => GND,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \P_div:count_1[2]~regout\);

-- Location: LC_X7_Y1_N0
\P_div:count_1[0]\ : maxii_lcell
-- Equation(s):
-- \P_div:count_1[0]~regout\ = DFFEAS(((!\P_div:count_1[0]~regout\ & ((\P_div:count_1[1]~regout\) # (!\P_div:count_1[2]~regout\)))), GLOBAL(\clk_in~combout\), VCC, , , , , , )

-- pragma translate_off
GENERIC MAP (
	lut_mask => "00f3",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	clk => \clk_in~combout\,
	datab => \P_div:count_1[2]~regout\,
	datac => \P_div:count_1[1]~regout\,
	datad => \P_div:count_1[0]~regout\,
	aclr => GND,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \P_div:count_1[0]~regout\);

-- Location: LC_X7_Y1_N8
\Equal0~0\ : maxii_lcell
-- Equation(s):
-- \Equal0~0_combout\ = ((!\P_div:count_1[0]~regout\ & (\P_div:count_1[2]~regout\ & !\P_div:count_1[1]~regout\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0030",
	operation_mode => "normal",
	output_mode => "comb_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	datab => \P_div:count_1[0]~regout\,
	datac => \P_div:count_1[2]~regout\,
	datad => \P_div:count_1[1]~regout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	combout => \Equal0~0_combout\);

-- Location: LC_X7_Y1_N5
temp_1 : maxii_lcell
-- Equation(s):
-- \temp_1~regout\ = DFFEAS((((!\temp_1~regout\))), GLOBAL(\clk_in~combout\), VCC, , \Equal0~0_combout\, , , , )

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0f0f",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	clk => \clk_in~combout\,
	datac => \temp_1~regout\,
	aclr => GND,
	ena => \Equal0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \temp_1~regout\);

-- Location: LC_X7_Y1_N7
\P_div:count_2[0]\ : maxii_lcell
-- Equation(s):
-- \P_div:count_2[0]~regout\ = DFFEAS(((!\P_div:count_2[0]~regout\ & (!\P_div:count_2[1]~regout\))), GLOBAL(\clk_in~combout\), VCC, , \Equal0~0_combout\, , , , )

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0303",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	clk => \clk_in~combout\,
	datab => \P_div:count_2[0]~regout\,
	datac => \P_div:count_2[1]~regout\,
	aclr => GND,
	ena => \Equal0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \P_div:count_2[0]~regout\);

-- Location: LC_X7_Y1_N4
\P_div:count_2[1]\ : maxii_lcell
-- Equation(s):
-- \P_div:count_2[1]~regout\ = DFFEAS(((\P_div:count_2[0]~regout\ & (!\P_div:count_2[1]~regout\))), GLOBAL(\clk_in~combout\), VCC, , \Equal0~0_combout\, , , , )

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0c0c",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	clk => \clk_in~combout\,
	datab => \P_div:count_2[0]~regout\,
	datac => \P_div:count_2[1]~regout\,
	aclr => GND,
	ena => \Equal0~0_combout\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \P_div:count_2[1]~regout\);

-- Location: LC_X7_Y1_N9
temp_2 : maxii_lcell
-- Equation(s):
-- \temp_2~regout\ = DFFEAS(\temp_2~regout\ $ (((\P_div:count_2[1]~regout\ & (!\P_div:count_2[0]~regout\ & \Equal0~0_combout\)))), GLOBAL(\clk_in~combout\), VCC, , , , , , )

-- pragma translate_off
GENERIC MAP (
	lut_mask => "c6cc",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	clk => \clk_in~combout\,
	dataa => \P_div:count_2[1]~regout\,
	datab => \temp_2~regout\,
	datac => \P_div:count_2[0]~regout\,
	datad => \Equal0~0_combout\,
	aclr => GND,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \temp_2~regout\);

-- Location: PIN_51,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
\clk_out_1~I\ : maxii_io
-- pragma translate_off
GENERIC MAP (
	operation_mode => "output")
-- pragma translate_on
PORT MAP (
	datain => \temp_1~regout\,
	oe => VCC,
	padio => ww_clk_out_1);

-- Location: PIN_53,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
\clk_out_2~I\ : maxii_io
-- pragma translate_off
GENERIC MAP (
	operation_mode => "output")
-- pragma translate_on
PORT MAP (
	datain => \temp_2~regout\,
	oe => VCC,
	padio => ww_clk_out_2);
END structure;


