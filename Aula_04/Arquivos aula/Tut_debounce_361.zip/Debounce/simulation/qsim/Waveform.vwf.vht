-- Copyright (C) 2018  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details.

-- *****************************************************************************
-- This file contains a Vhdl test bench with test vectors .The test vectors     
-- are exported from a vector file in the Quartus Waveform Editor and apply to  
-- the top level entity of the current Quartus project .The user can use this   
-- testbench to simulate his design using a third-party simulation tool .       
-- *****************************************************************************
-- Generated on "04/08/2020 15:24:52"
                                                             
-- Vhdl Test Bench(with test vectors) for design  :          debounce_v1
-- 
-- Simulation tool : 3rd Party
-- 

LIBRARY ieee;                                               
USE ieee.std_logic_1164.all;                                

ENTITY debounce_v1_vhd_vec_tst IS
END debounce_v1_vhd_vec_tst;
ARCHITECTURE debounce_v1_arch OF debounce_v1_vhd_vec_tst IS
-- constants                                                 
-- signals                                                   
SIGNAL button : STD_LOGIC;
SIGNAL clk : STD_LOGIC;
SIGNAL result : STD_LOGIC;
COMPONENT debounce_v1
	PORT (
	button : IN STD_LOGIC;
	clk : IN STD_LOGIC;
	result : OUT STD_LOGIC
	);
END COMPONENT;
BEGIN
	i1 : debounce_v1
	PORT MAP (
-- list connections between master ports and signals
	button => button,
	clk => clk,
	result => result
	);

-- clk
t_prcs_clk: PROCESS
BEGIN
LOOP
	clk <= '0';
	WAIT FOR 25000 ps;
	clk <= '1';
	WAIT FOR 25000 ps;
	IF (NOW >= 1000000 ps) THEN WAIT; END IF;
END LOOP;
END PROCESS t_prcs_clk;

-- button
t_prcs_button: PROCESS
BEGIN
	button <= '0';
	WAIT FOR 30000 ps;
	button <= '1';
	WAIT FOR 80000 ps;
	button <= '0';
	WAIT FOR 130000 ps;
	button <= '1';
	WAIT FOR 160000 ps;
	button <= '0';
	WAIT FOR 70000 ps;
	button <= '1';
	WAIT FOR 220000 ps;
	button <= '0';
WAIT;
END PROCESS t_prcs_button;
END debounce_v1_arch;
