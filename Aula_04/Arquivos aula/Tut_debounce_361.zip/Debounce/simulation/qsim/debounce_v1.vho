-- Copyright (C) 2018  Intel Corporation. All rights reserved.
-- Your use of Intel Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Intel Program License 
-- Subscription Agreement, the Intel Quartus Prime License Agreement,
-- the Intel FPGA IP License Agreement, or other applicable license
-- agreement, including, without limitation, that your use is for
-- the sole purpose of programming logic devices manufactured by
-- Intel and sold by Intel or its authorized distributors.  Please
-- refer to the applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus Prime"
-- VERSION "Version 18.1.0 Build 625 09/12/2018 SJ Lite Edition"

-- DATE "04/08/2020 15:24:57"

-- 
-- Device: Altera EPM240T100C5 Package TQFP100
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY IEEE;
LIBRARY MAXII;
USE IEEE.STD_LOGIC_1164.ALL;
USE MAXII.MAXII_COMPONENTS.ALL;

ENTITY 	debounce_v1 IS
    PORT (
	clk : IN std_logic;
	button : IN std_logic;
	result : OUT std_logic
	);
END debounce_v1;

-- Design Ports Information


ARCHITECTURE structure OF debounce_v1 IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk : std_logic;
SIGNAL ww_button : std_logic;
SIGNAL ww_result : std_logic;
SIGNAL \clk~combout\ : std_logic;
SIGNAL \button~combout\ : std_logic;
SIGNAL \result~0_combout\ : std_logic;
SIGNAL \result~reg0_regout\ : std_logic;
SIGNAL flipflops : std_logic_vector(1 DOWNTO 0);
SIGNAL counter_out : std_logic_vector(1 DOWNTO 0);

BEGIN

ww_clk <= clk;
ww_button <= button;
result <= ww_result;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

-- Location: PIN_14,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
\clk~I\ : maxii_io
-- pragma translate_off
GENERIC MAP (
	operation_mode => "input")
-- pragma translate_on
PORT MAP (
	oe => GND,
	padio => ww_clk,
	combout => \clk~combout\);

-- Location: PIN_53,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: Default
\button~I\ : maxii_io
-- pragma translate_off
GENERIC MAP (
	operation_mode => "input")
-- pragma translate_on
PORT MAP (
	oe => GND,
	padio => ww_button,
	combout => \button~combout\);

-- Location: LC_X7_Y1_N6
\flipflops[0]\ : maxii_lcell
-- Equation(s):
-- flipflops(0) = DFFEAS(GND, GLOBAL(\clk~combout\), VCC, , , \button~combout\, , , VCC)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "on")
-- pragma translate_on
PORT MAP (
	clk => \clk~combout\,
	datac => \button~combout\,
	aclr => GND,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => flipflops(0));

-- Location: LC_X7_Y1_N7
\flipflops[1]\ : maxii_lcell
-- Equation(s):
-- flipflops(1) = DFFEAS(GND, GLOBAL(\clk~combout\), VCC, , , flipflops(0), , , VCC)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "on")
-- pragma translate_on
PORT MAP (
	clk => \clk~combout\,
	datac => flipflops(0),
	aclr => GND,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => flipflops(1));

-- Location: LC_X7_Y1_N2
\counter_out[0]\ : maxii_lcell
-- Equation(s):
-- counter_out(0) = DFFEAS((counter_out(1) & (flipflops(0) $ ((!flipflops(1))))) # (!counter_out(1) & (!counter_out(0) & (flipflops(0) $ (!flipflops(1))))), GLOBAL(\clk~combout\), VCC, , , , , , )

-- pragma translate_off
GENERIC MAP (
	lut_mask => "9099",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	clk => \clk~combout\,
	dataa => flipflops(0),
	datab => flipflops(1),
	datac => counter_out(1),
	datad => counter_out(0),
	aclr => GND,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => counter_out(0));

-- Location: LC_X7_Y1_N0
\counter_out[1]\ : maxii_lcell
-- Equation(s):
-- counter_out(1) = DFFEAS((counter_out(1) & (flipflops(0) $ ((!flipflops(1))))) # (!counter_out(1) & (counter_out(0) & (flipflops(0) $ (!flipflops(1))))), GLOBAL(\clk~combout\), VCC, , , , , , )

-- pragma translate_off
GENERIC MAP (
	lut_mask => "9990",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	clk => \clk~combout\,
	dataa => flipflops(0),
	datab => flipflops(1),
	datac => counter_out(1),
	datad => counter_out(0),
	aclr => GND,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => counter_out(1));

-- Location: LC_X7_Y1_N4
\result~0\ : maxii_lcell
-- Equation(s):
-- \result~0_combout\ = (((counter_out(1) & counter_out(0))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "f000",
	operation_mode => "normal",
	output_mode => "comb_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	datac => counter_out(1),
	datad => counter_out(0),
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	combout => \result~0_combout\);

-- Location: LC_X7_Y1_N5
\result~reg0\ : maxii_lcell
-- Equation(s):
-- \result~reg0_regout\ = DFFEAS((flipflops(0) & ((\result~reg0_regout\) # ((flipflops(1) & \result~0_combout\)))) # (!flipflops(0) & (\result~reg0_regout\ & ((flipflops(1)) # (!\result~0_combout\)))), GLOBAL(\clk~combout\), VCC, , , , , , )

-- pragma translate_off
GENERIC MAP (
	lut_mask => "e8f0",
	operation_mode => "normal",
	output_mode => "reg_only",
	register_cascade_mode => "off",
	sum_lutc_input => "datac",
	synch_mode => "off")
-- pragma translate_on
PORT MAP (
	clk => \clk~combout\,
	dataa => flipflops(0),
	datab => flipflops(1),
	datac => \result~reg0_regout\,
	datad => \result~0_combout\,
	aclr => GND,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	regout => \result~reg0_regout\);

-- Location: PIN_51,	 I/O Standard: 3.3-V LVTTL,	 Current Strength: 16mA
\result~I\ : maxii_io
-- pragma translate_off
GENERIC MAP (
	operation_mode => "output")
-- pragma translate_on
PORT MAP (
	datain => \result~reg0_regout\,
	oe => VCC,
	padio => ww_result);
END structure;


